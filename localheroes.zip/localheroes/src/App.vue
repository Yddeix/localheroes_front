<script setup>
    import '@/assets/style.css'
</script>

<template>
    <RouterView />
</template>

<style scoped></style>
