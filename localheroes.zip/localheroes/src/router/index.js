import { createRouter, createWebHistory } from 'vue-router'

import login from '@/view/login.vue'
import register from '@/view/register.vue'

const routes = [
  {path: '/', name: 'login', component: login},
  {path: '/register', name: 'register', component: register}
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'login',
      component: login,
    },
    {
      path: '/register',
      name: 'register',
      component: register,
    }
  ],
})

export default router
