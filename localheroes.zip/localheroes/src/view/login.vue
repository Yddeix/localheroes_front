<script setup></script>

<template>
    <h2>Bienvenue</h2>
    <div class="container">
        <div class="form-box">
        <h3>Connexion</h3>
        <form action="#" method="post">
            <input type="email" placeholder="Email" id="log_mail">
            <input type="password" placeholder="Mot de passe" id="pss_log">
            <button type="submit" id="lit">Se connecter</button>
            <p>Pas encore de compte ? <router-link to="/register">S'enregistrer</router-link></p>
        </form>
        </div>

    </div>
</template>

<style scoped>
h2 {
    text-align: center;
    color: #333;
}

.container {
    display: flex;
    gap: 30px;
    justify-content: center;
    flex-wrap: wrap;
}

.form-box {
    background-color: white;
    padding: 20px;
    border-radius: 10px;
    width: 300px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.form-box h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #444;
}

.form-box input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-box button {
    width: 100%;
    padding: 10px;
    background-color: #4A90E2;
    color: white;
    border: none;
    border-radius: 5px;
    font-weight: bold;
}

.form-box button:hover {
    background-color: #357ABD;
}
</style>